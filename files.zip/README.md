# MF Holdings API

Serves parsed Indian mutual fund portfolio holdings as JSON.
Auto-fetches AMC monthly Excel disclosures. No upload needed.

## Endpoints

```
GET /holdings?fund=Sundaram+Mid+Cap+Fund
GET /search?q=hdfc+top
GET /funds
GET /health
POST /refresh?secret=YOUR_SECRET
```

## Deploy to Render (free, ~2 min setup)

1. Push this folder to a GitHub repo
2. Go to render.com → New → Web Service → connect your repo
3. Render auto-detects render.yaml and deploys
4. Copy the URL (e.g. https://mf-holdings-api.onrender.com)
5. Paste into MF Analyser settings

## Local dev

```bash
pip install -r requirements.txt
uvicorn main:app --reload
# API at http://localhost:8000
```

## Response format

```json
GET /holdings?fund=Sundaram+Mid+Cap+Fund

{
  "fund_name": "Sundaram Mid Cap Fund",
  "amc": "Sundaram",
  "holdings": [
    { "name": "Tube Investments of India", "isin": "INE974X01010", "sector": "Capital Goods", "pct": 4.23 },
    { "name": "Cummins India", "isin": "INE298A01020", "sector": "Capital Goods", "pct": 3.87 }
  ],
  "count": 58
}
```

## Data sources

SEBI-mandated monthly portfolio disclosures from each AMC.
Auto-refreshes on 10th of each month at 09:00 IST.
Covers: SBI, HDFC, ICICI, Nippon, Kotak, Mirae, Axis, UTI, ABSL,
DSP, Franklin, Tata, Motilal, Canara Robeco, PPFAS, Quant, WhiteOak + more.

Sundaram uses PDF-only disclosures — not covered by auto-fetch.
